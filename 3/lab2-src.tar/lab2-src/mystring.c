
#include <stdlib.h>
#include "mystring.h"

// Type "man string" to see what every function expects.

int mystrlen(char * s) {
	return 0;
}

char * mystrcpy(char * dest, char * src) {
	return NULL;
}

char * mystrcat(char * dest, char * src) {
	return NULL;
}

int mystrcmp(char * s1, char * s2) {
	return -1;
}

char * mystrstr(char * hay, char * needle) {
	return NULL;
}

char * mystrdup(char * s) {
	return NULL;
}

char * mymemcpy(char * dest, char * src, int n)
{
	return NULL;
}

